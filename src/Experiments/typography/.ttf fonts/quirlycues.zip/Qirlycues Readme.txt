

ENJOY this font it is free for PERSONAL use only, but if you do wish to use it for any commercial purpose please contact me at the email address below and i shall issue a license.  

I do quite a lot of commercial work myself and am always interested in how and why designers choose and use fonts. 

Email me at:
qabbojo@gmail.com

See some of my artwork at:
www.chess-theory.com, Virtual Art Museum
 - or Google 'Joanne Taylor Knysna'

