If you want to use this font for commercial use please donate me or contact me first


For donations:
https://www.paypal.com/nl/cgi-bin/webscr?cmd=_flow&SESSION=-LIYlegiEOGjTZ-dSeE82qPz-H0fsmA0V8DgzGfcCPvUxmgtdI307deQTwG&dispatch=50a222a57771920b6a3d7b606239e4d529b525e0b7e69bf0224adecfb0124e9bdd7275a399ffdb502f5df4e499ae8456658a8e60c7f4ec16

For information:
info@nls-ontwerpers.nl