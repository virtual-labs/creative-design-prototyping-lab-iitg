A Sensible Armadillo (c) Brittney Murphy 2010
www.brittneymurphydesign.com
info@brittneymurphydesign.com

"A Sensible Armadillo" is a font created and copyrighted by Brittney Murphy.

It is free for personal and non-profit use.  If you would like to use this font commercially, please purchase a commercial license (only $5) at www.brittneymurphydesign.com.

You are free to redistribute this font as long as you include this ReadMe file with the font file and don't try to claim the font as free or as your own.

